"""
risk_manager.py — Capital preservation & position sizing engine
"""

import logging
from dataclasses import dataclass, field
from datetime import date
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class RiskConfig:
    account_balance: float = 10_000.0          # Starting/current balance
    risk_per_trade_pct: float = 1.0            # 1–2% risk per trade
    max_daily_loss_pct: float = 5.0            # Hard stop for the day
    max_drawdown_pct: float = 15.0             # Pause threshold
    min_rr_ratio: float = 2.0                  # Minimum reward:risk
    max_trades_per_day: int = 5
    max_spread_pips: float = 3.0               # Max acceptable spread
    max_slippage_pips: float = 2.0


@dataclass
class DailyStats:
    date: date = field(default_factory=date.today)
    trades_taken: int = 0
    realized_pnl: float = 0.0
    peak_equity: float = 0.0
    trading_halted: bool = False
    halt_reason: str = ""


class RiskManager:
    """
    Central risk engine — enforces all risk rules before any trade fires.
    Returns (allowed: bool, reason: str) for every trade request.
    """

    def __init__(self, config: RiskConfig):
        self.cfg = config
        self.daily = DailyStats(peak_equity=config.account_balance)
        self._kill_switch_active = False
        self._peak_balance = config.account_balance

    # ------------------------------------------------------------------ #
    #  PUBLIC INTERFACE                                                    #
    # ------------------------------------------------------------------ #

    def can_trade(self) -> tuple[bool, str]:
        """Master gate — call before every trade attempt."""
        if self._kill_switch_active:
            return False, "KILL SWITCH active — manual restart required"
        if self.daily.trading_halted:
            return False, f"Trading halted: {self.daily.halt_reason}"
        if self.daily.trades_taken >= self.cfg.max_trades_per_day:
            return False, f"Daily trade limit reached ({self.cfg.max_trades_per_day})"
        return True, "OK"

    def check_spread(self, spread_pips: float) -> tuple[bool, str]:
        if spread_pips > self.cfg.max_spread_pips:
            return False, f"Spread {spread_pips:.1f} pips exceeds limit {self.cfg.max_spread_pips}"
        return True, "OK"

    def check_slippage(self, slippage_pips: float) -> tuple[bool, str]:
        if abs(slippage_pips) > self.cfg.max_slippage_pips:
            return False, f"Slippage {slippage_pips:.1f} pips exceeds limit"
        return True, "OK"

    def calculate_lot_size(
        self,
        entry: float,
        stop_loss: float,
        pip_value_per_lot: float = 10.0,  # standard lot, USD account
        pip_size: float = 0.0001,
    ) -> float:
        """
        Risk-based position sizing.
        lot_size = (balance * risk_pct) / (SL_pips * pip_value_per_lot)
        """
        sl_pips = abs(entry - stop_loss) / pip_size
        if sl_pips == 0:
            logger.error("Stop-loss distance is zero — trade rejected")
            return 0.0
        risk_amount = self.cfg.account_balance * (self.cfg.risk_per_trade_pct / 100)
        lot_size = risk_amount / (sl_pips * pip_value_per_lot)
        lot_size = round(max(0.01, min(lot_size, 100.0)), 2)  # clamp to sane range
        logger.info(
            "Position size: %.2f lots | SL=%.1f pips | Risk=$%.2f",
            lot_size, sl_pips, risk_amount,
        )
        return lot_size

    def validate_rr(self, entry: float, stop_loss: float, take_profit: float) -> tuple[bool, str]:
        """Enforce minimum risk:reward ratio."""
        risk = abs(entry - stop_loss)
        reward = abs(take_profit - entry)
        if risk == 0:
            return False, "Zero risk distance"
        rr = reward / risk
        if rr < self.cfg.min_rr_ratio:
            return False, f"R:R {rr:.2f} below minimum {self.cfg.min_rr_ratio}"
        return True, f"R:R {rr:.2f} ✓"

    def record_trade_result(self, pnl: float, equity: float) -> None:
        """Update daily stats and check protection thresholds."""
        self.daily.trades_taken += 1
        self.daily.realized_pnl += pnl
        self.daily.peak_equity = max(self.daily.peak_equity, equity)

        # Update peak balance for drawdown calc
        self._peak_balance = max(self._peak_balance, equity)

        # Daily loss limit
        daily_loss_pct = (self.daily.realized_pnl / self.cfg.account_balance) * 100
        if daily_loss_pct <= -self.cfg.max_daily_loss_pct:
            self._halt(f"Daily loss limit hit ({daily_loss_pct:.1f}%)")
            return

        # Max drawdown
        drawdown_pct = ((self._peak_balance - equity) / self._peak_balance) * 100
        if drawdown_pct >= self.cfg.max_drawdown_pct:
            self._halt(f"Max drawdown hit ({drawdown_pct:.1f}%) — manual restart required")

    def reset_daily(self) -> None:
        """Call at the start of each trading day."""
        self.daily = DailyStats(peak_equity=self.cfg.account_balance)
        logger.info("Daily stats reset for %s", date.today())

    def activate_kill_switch(self) -> None:
        """Emergency stop — halts ALL activity immediately."""
        self._kill_switch_active = True
        logger.critical("⚠️  KILL SWITCH ACTIVATED — all trading stopped")

    def deactivate_kill_switch(self) -> None:
        """Manual restart after kill switch."""
        self._kill_switch_active = False
        logger.warning("Kill switch deactivated — trading can resume")

    # ------------------------------------------------------------------ #
    #  PRIVATE                                                             #
    # ------------------------------------------------------------------ #

    def _halt(self, reason: str) -> None:
        self.daily.trading_halted = True
        self.daily.halt_reason = reason
        logger.critical("🛑 TRADING HALTED: %s", reason)
