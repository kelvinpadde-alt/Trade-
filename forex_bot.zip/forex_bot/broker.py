"""
broker.py — Abstract broker interface + OANDA REST v20 adapter
Swap in any broker by implementing BrokerBase.
"""

import logging
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional

import requests

logger = logging.getLogger(__name__)


@dataclass
class OrderResult:
    success: bool
    order_id: str
    fill_price: float
    message: str


@dataclass
class AccountState:
    balance: float
    equity: float
    margin_used: float
    unrealized_pnl: float


@dataclass
class MarketData:
    symbol: str
    bid: float
    ask: float
    spread_pips: float
    closes: list
    highs: list
    lows: list


class BrokerBase(ABC):
    """Abstract interface — implement this for any broker."""

    @abstractmethod
    def get_account(self) -> AccountState: ...

    @abstractmethod
    def get_market_data(self, symbol: str, count: int = 300) -> MarketData: ...

    @abstractmethod
    def place_order(
        self, symbol: str, direction: str, lots: float,
        stop_loss: float, take_profit: float
    ) -> OrderResult: ...

    @abstractmethod
    def close_order(self, order_id: str) -> bool: ...

    @abstractmethod
    def get_open_orders(self) -> list[dict]: ...


# ──────────────────────────────────────────────────────────────────────────── #
#  OANDA REST v20 Adapter                                                       #
# ──────────────────────────────────────────────────────────────────────────── #

class OandaBroker(BrokerBase):
    """
    Production adapter for OANDA REST v20.
    Set practice=True for demo trading (recommended before going live).
    """

    BASE_PRACTICE = "https://api-fxpractice.oanda.com/v3"
    BASE_LIVE      = "https://api-fxtrade.oanda.com/v3"

    def __init__(self, api_key: str, account_id: str, practice: bool = True):
        self.account_id = account_id
        self.base_url   = self.BASE_PRACTICE if practice else self.BASE_LIVE
        self.session    = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type":  "application/json",
        })
        mode = "PRACTICE" if practice else "LIVE"
        logger.info("OandaBroker initialized — %s mode", mode)

    def get_account(self) -> AccountState:
        resp = self._get(f"/accounts/{self.account_id}/summary")
        acct = resp["account"]
        return AccountState(
            balance        = float(acct["balance"]),
            equity         = float(acct["NAV"]),
            margin_used    = float(acct["marginUsed"]),
            unrealized_pnl = float(acct["unrealizedPL"]),
        )

    def get_market_data(self, symbol: str, count: int = 300) -> MarketData:
        # Convert symbol format: EURUSD → EUR_USD
        instrument = f"{symbol[:3]}_{symbol[3:]}" if "_" not in symbol else symbol

        # Candles
        params = {"count": count, "granularity": "H1", "price": "M"}
        resp = self._get(f"/instruments/{instrument}/candles", params=params)
        candles = resp["candles"]

        closes = [float(c["mid"]["c"]) for c in candles]
        highs  = [float(c["mid"]["h"]) for c in candles]
        lows   = [float(c["mid"]["l"]) for c in candles]

        # Pricing
        price_resp = self._get(f"/accounts/{self.account_id}/pricing",
                               params={"instruments": instrument})
        prices = price_resp["prices"][0]
        bid    = float(prices["bids"][0]["price"])
        ask    = float(prices["asks"][0]["price"])
        spread = round((ask - bid) / 0.0001, 1)

        return MarketData(
            symbol=symbol, bid=bid, ask=ask,
            spread_pips=spread, closes=closes, highs=highs, lows=lows,
        )

    def place_order(
        self, symbol: str, direction: str, lots: float,
        stop_loss: float, take_profit: float,
    ) -> OrderResult:
        instrument = f"{symbol[:3]}_{symbol[3:]}" if "_" not in symbol else symbol
        units = int(lots * 100_000)
        if direction == "SELL":
            units = -units

        order = {
            "order": {
                "type":        "MARKET",
                "instrument":  instrument,
                "units":       str(units),
                "timeInForce": "FOK",
                "stopLossOnFill":   {"price": f"{stop_loss:.5f}"},
                "takeProfitOnFill": {"price": f"{take_profit:.5f}"},
            }
        }

        try:
            resp = self._post(f"/accounts/{self.account_id}/orders", order)
            fill  = resp.get("orderFillTransaction", {})
            price = float(fill.get("price", 0))
            oid   = fill.get("id", str(uuid.uuid4()))
            return OrderResult(success=True, order_id=oid,
                               fill_price=price, message="Order filled")
        except Exception as e:
            return OrderResult(success=False, order_id="", fill_price=0, message=str(e))

    def close_order(self, order_id: str) -> bool:
        try:
            self._put(f"/accounts/{self.account_id}/trades/{order_id}/close")
            return True
        except Exception as e:
            logger.error("Failed to close order %s: %s", order_id, e)
            return False

    def get_open_orders(self) -> list[dict]:
        resp = self._get(f"/accounts/{self.account_id}/openTrades")
        return resp.get("trades", [])

    # ── HTTP helpers ────────────────────────────────────────────────────

    def _get(self, path: str, params: dict = None) -> dict:
        r = self.session.get(self.base_url + path, params=params, timeout=10)
        r.raise_for_status()
        return r.json()

    def _post(self, path: str, payload: dict) -> dict:
        r = self.session.post(self.base_url + path, json=payload, timeout=10)
        r.raise_for_status()
        return r.json()

    def _put(self, path: str, payload: dict = None) -> dict:
        r = self.session.put(self.base_url + path, json=payload or {}, timeout=10)
        r.raise_for_status()
        return r.json()


# ──────────────────────────────────────────────────────────────────────────── #
#  Paper / Backtest Broker (no real orders)                                     #
# ──────────────────────────────────────────────────────────────────────────── #

class PaperBroker(BrokerBase):
    """
    In-memory simulated broker for backtesting and forward testing.
    Simulates fills, SL/TP hits, and account equity.
    """

    def __init__(self, starting_balance: float = 10_000.0):
        self._balance = starting_balance
        self._equity  = starting_balance
        self._orders: dict[str, dict] = {}
        logger.info("PaperBroker initialized | Balance=$%.2f", starting_balance)

    def get_account(self) -> AccountState:
        return AccountState(
            balance=self._balance, equity=self._equity,
            margin_used=0.0, unrealized_pnl=0.0,
        )

    def get_market_data(self, symbol: str, count: int = 300) -> MarketData:
        raise NotImplementedError("Inject price data for backtesting via simulate()")

    def place_order(self, symbol, direction, lots, stop_loss, take_profit) -> OrderResult:
        oid = str(uuid.uuid4())[:8]
        self._orders[oid] = dict(
            symbol=symbol, direction=direction, lots=lots,
            stop_loss=stop_loss, take_profit=take_profit, open=True,
        )
        logger.info("PAPER ORDER #%s | %s %s %.2f lots | SL=%.5f TP=%.5f",
                    oid, direction, symbol, lots, stop_loss, take_profit)
        return OrderResult(success=True, order_id=oid,
                           fill_price=0.0, message="Paper fill")

    def close_order(self, order_id: str) -> bool:
        if order_id in self._orders:
            self._orders[order_id]["open"] = False
            return True
        return False

    def get_open_orders(self) -> list[dict]:
        return [o for o in self._orders.values() if o["open"]]

    def simulate_close(self, order_id: str, close_price: float, pip_value: float = 10.0):
        """Manually close a paper trade and update equity."""
        order = self._orders.get(order_id)
        if not order:
            return
        direction = order["direction"]
        lots = order["lots"]
        entry = order.get("entry_price", close_price)
        pip_diff = (close_price - entry) / 0.0001
        if direction == "SELL":
            pip_diff = -pip_diff
        pnl = pip_diff * pip_value * lots
        self._equity += pnl
        self._balance += pnl
        self._orders[order_id]["open"] = False
        logger.info("PAPER CLOSE #%s | PnL=$%.2f | Equity=$%.2f",
                    order_id, pnl, self._equity)
        return pnl
