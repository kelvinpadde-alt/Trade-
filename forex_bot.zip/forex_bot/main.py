"""
main.py — Entry point: configure and launch the bot
"""

import logging
import os
import sys
from datetime import datetime, timezone

# ── Logging setup ──────────────────────────────────────────────────────────
logging.basicConfig(
    level   = logging.INFO,
    format  = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/bot.log"),
    ],
)
logger = logging.getLogger(__name__)

# ── Bot imports ────────────────────────────────────────────────────────────
from bot import ForexBot
from broker import OandaBroker, PaperBroker
from risk_manager import RiskConfig
from strategy import StrategyConfig


# ══════════════════════════════════════════════════════════════════════════ #
#  CONFIGURATION — edit these values before deployment                       #
# ══════════════════════════════════════════════════════════════════════════ #

RISK_CONFIG = RiskConfig(
    account_balance     = 10_000.0,   # Your starting account balance
    risk_per_trade_pct  = 1.0,        # 1% risk per trade (conservative)
    max_daily_loss_pct  = 5.0,        # Stop trading after 5% daily loss
    max_drawdown_pct    = 15.0,       # Pause if equity drops 15%
    min_rr_ratio        = 2.0,        # Minimum 1:2 reward-to-risk
    max_trades_per_day  = 5,          # Hard cap on daily trades
    max_spread_pips     = 3.0,        # Max acceptable spread
    max_slippage_pips   = 2.0,        # Max acceptable slippage
)

STRATEGY_CONFIG = StrategyConfig(
    ema_fast            = 21,
    ema_slow            = 50,
    ema_trend           = 200,
    rsi_period          = 14,
    rsi_overbought      = 70.0,
    rsi_oversold        = 30.0,
    atr_period          = 14,
    atr_sl_multiplier   = 1.5,        # SL = 1.5× ATR
    atr_tp_multiplier   = 3.0,        # TP = 3.0× ATR (2:1 R:R guaranteed)
    min_atr_pips        = 5.0,
    max_atr_pips        = 50.0,
)

SYMBOLS = ["EURUSD", "GBPUSD", "USDJPY"]  # Add/remove as needed

# Set DEMO_MODE=False ONLY when ready for live trading
DEMO_MODE = True

OANDA_API_KEY    = os.getenv("OANDA_API_KEY", "your_api_key_here")
OANDA_ACCOUNT_ID = os.getenv("OANDA_ACCOUNT_ID", "your_account_id_here")

CANDLE_INTERVAL_SECONDS = 3600  # 1 hour

# ══════════════════════════════════════════════════════════════════════════ #


def run_live():
    """Start live (or demo) trading."""
    if DEMO_MODE:
        logger.info("🧪 DEMO mode — using PaperBroker (no real orders)")
        broker = PaperBroker(starting_balance=RISK_CONFIG.account_balance)
    else:
        logger.warning("⚠️  LIVE TRADING MODE — real money at risk")
        confirm = input("Type 'LIVE' to confirm live trading: ")
        if confirm.strip() != "LIVE":
            logger.info("Confirmation failed — aborting")
            return
        broker = OandaBroker(
            api_key    = OANDA_API_KEY,
            account_id = OANDA_ACCOUNT_ID,
            practice   = False,
        )

    bot = ForexBot(
        broker          = broker,
        symbols         = SYMBOLS,
        risk_config     = RISK_CONFIG,
        strategy_config = STRATEGY_CONFIG,
        log_dir         = "logs",
    )

    try:
        bot.start(interval_seconds=CANDLE_INTERVAL_SECONDS)
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt — shutting down")
    finally:
        bot.report()


def run_backtest():
    """Run a quick demo backtest with synthetic price data."""
    import numpy as np
    from backtester import Backtester, OHLCV

    logger.info("Running demo backtest with synthetic data...")

    # Generate synthetic trending price data
    np.random.seed(42)
    n = 1000
    prices = [1.10000]
    for _ in range(n - 1):
        change = np.random.normal(0.00005, 0.0008)
        prices.append(max(0.5, prices[-1] + change))

    candles = []
    for p in prices:
        h = p + abs(np.random.normal(0, 0.0003))
        l = p - abs(np.random.normal(0, 0.0003))
        candles.append(OHLCV(open=p, high=h, low=l, close=p))

    bt = Backtester(candles=candles, risk_config=RISK_CONFIG,
                    strategy_config=STRATEGY_CONFIG)
    results = bt.run(warmup=250)
    return results


if __name__ == "__main__":
    import argparse
    import os

    os.makedirs("logs", exist_ok=True)

    parser = argparse.ArgumentParser(description="Forex Trading Bot")
    parser.add_argument("--mode", choices=["live", "backtest"], default="backtest")
    args = parser.parse_args()

    if args.mode == "backtest":
        run_backtest()
    else:
        run_live()
