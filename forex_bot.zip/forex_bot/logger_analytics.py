"""
logger_analytics.py — Trade journaling and performance reporting
"""

import csv
import json
import logging
import os
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import List, Optional

logger = logging.getLogger(__name__)


@dataclass
class TradeRecord:
    trade_id: str
    symbol: str
    direction: str           # BUY / SELL
    open_time: str
    close_time: str
    entry_price: float
    exit_price: float
    stop_loss: float
    take_profit: float
    lot_size: float
    pnl: float               # USD
    pnl_pips: float
    outcome: str             # WIN / LOSS / BREAKEVEN
    close_reason: str        # SL / TP / MANUAL / KILL_SWITCH
    spread_pips: float
    atr: float
    signal_reason: str


class TradeLogger:
    """Appends trade records to CSV and JSON. Thread-safe via simple file locks."""

    def __init__(self, log_dir: str = "logs"):
        os.makedirs(log_dir, exist_ok=True)
        self.csv_path  = os.path.join(log_dir, "trades.csv")
        self.json_path = os.path.join(log_dir, "trades.json")
        self._records: List[TradeRecord] = []
        self._load_existing()

    def log(self, record: TradeRecord) -> None:
        self._records.append(record)
        self._append_csv(record)
        self._rewrite_json()
        logger.info(
            "TRADE LOGGED | %s %s | Entry=%.5f Exit=%.5f | PnL=$%.2f (%s)",
            record.direction, record.symbol, record.entry_price,
            record.exit_price, record.pnl, record.outcome,
        )

    def analytics(self) -> dict:
        """Compute key performance metrics from trade history."""
        if not self._records:
            return {"message": "No trades recorded yet"}

        wins   = [r for r in self._records if r.outcome == "WIN"]
        losses = [r for r in self._records if r.outcome == "LOSS"]
        total  = len(self._records)

        total_pnl   = sum(r.pnl for r in self._records)
        gross_profit = sum(r.pnl for r in wins)
        gross_loss   = abs(sum(r.pnl for r in losses))
        profit_factor = (gross_profit / gross_loss) if gross_loss > 0 else float("inf")

        pips_total  = sum(r.pnl_pips for r in self._records)

        # Max drawdown from equity curve
        equity = 0.0
        peak   = 0.0
        max_dd = 0.0
        for r in self._records:
            equity += r.pnl
            peak    = max(peak, equity)
            max_dd  = max(max_dd, peak - equity)

        # Consecutive losses
        max_consec_loss = 0
        cur_consec      = 0
        for r in self._records:
            if r.outcome == "LOSS":
                cur_consec += 1
                max_consec_loss = max(max_consec_loss, cur_consec)
            else:
                cur_consec = 0

        return {
            "total_trades":        total,
            "wins":                len(wins),
            "losses":              len(losses),
            "win_rate_pct":        round(len(wins) / total * 100, 1),
            "total_pnl_usd":       round(total_pnl, 2),
            "total_pips":          round(pips_total, 1),
            "profit_factor":       round(profit_factor, 2),
            "avg_win_usd":         round(gross_profit / len(wins), 2) if wins else 0,
            "avg_loss_usd":        round(-gross_loss / len(losses), 2) if losses else 0,
            "max_drawdown_usd":    round(max_dd, 2),
            "max_consec_losses":   max_consec_loss,
        }

    def print_report(self) -> None:
        stats = self.analytics()
        sep = "─" * 45
        print(f"\n{sep}")
        print("  TRADING PERFORMANCE REPORT")
        print(sep)
        for k, v in stats.items():
            label = k.replace("_", " ").title()
            print(f"  {label:<28} {v}")
        print(f"{sep}\n")

    # ── Private ────────────────────────────────────────────────────────

    def _append_csv(self, record: TradeRecord) -> None:
        write_header = not os.path.exists(self.csv_path)
        with open(self.csv_path, "a", newline="") as f:
            w = csv.DictWriter(f, fieldnames=asdict(record).keys())
            if write_header:
                w.writeheader()
            w.writerow(asdict(record))

    def _rewrite_json(self) -> None:
        with open(self.json_path, "w") as f:
            json.dump([asdict(r) for r in self._records], f, indent=2)

    def _load_existing(self) -> None:
        if not os.path.exists(self.json_path):
            return
        try:
            with open(self.json_path) as f:
                data = json.load(f)
            self._records = [TradeRecord(**d) for d in data]
            logger.info("Loaded %d existing trade records", len(self._records))
        except Exception as e:
            logger.warning("Could not load trade history: %s", e)
