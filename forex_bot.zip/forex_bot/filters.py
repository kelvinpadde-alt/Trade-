"""
filters.py — Session, news, and market condition filters
"""

from datetime import datetime, time, timezone
import logging

logger = logging.getLogger(__name__)


# Trading session definitions (UTC)
SESSIONS = {
    "London":   (time(7, 0),  time(16, 0)),
    "New_York":  (time(13, 0), time(22, 0)),
    "Overlap":   (time(13, 0), time(16, 0)),  # Highest liquidity
}


class SessionFilter:
    """
    Only allow trading during London and New York sessions.
    Avoids low-volume Asian and Pacific sessions by default.
    """

    def __init__(self, allowed_sessions: list[str] | None = None):
        self.allowed = allowed_sessions or ["London", "New_York"]

    def is_active(self, now: datetime | None = None) -> tuple[bool, str]:
        now = now or datetime.now(timezone.utc)
        t = now.time().replace(tzinfo=None)

        for session in self.allowed:
            start, end = SESSIONS[session]
            if start <= t <= end:
                return True, f"{session} session active"

        return False, f"Outside trading sessions (UTC {t.strftime('%H:%M')})"


class NewsFilter:
    """
    Simple news blackout window filter.
    In production, integrate with Forex Factory or similar calendar API.
    Provide a list of high-impact event times to avoid.
    """

    def __init__(self, blackout_minutes_before: int = 30,
                 blackout_minutes_after: int = 30):
        self.before = blackout_minutes_before
        self.after  = blackout_minutes_after
        self._events: list[datetime] = []

    def add_event(self, event_time: datetime) -> None:
        self._events.append(event_time)

    def is_safe(self, now: datetime | None = None) -> tuple[bool, str]:
        now = now or datetime.now(timezone.utc)
        for event in self._events:
            delta_minutes = (event - now).total_seconds() / 60
            if -self.after <= delta_minutes <= self.before:
                return False, f"News blackout window ({delta_minutes:.0f} min from event)"
        return True, "No news events nearby"


class VolatilityFilter:
    """
    Rejects trades when ATR is outside acceptable bounds.
    Strategy engine handles this — this is the shared utility.
    """

    def __init__(self, min_atr_pips: float = 5.0, max_atr_pips: float = 50.0):
        self.min = min_atr_pips
        self.max = max_atr_pips

    def is_acceptable(self, atr_pips: float) -> tuple[bool, str]:
        if atr_pips < self.min:
            return False, f"Too quiet: ATR={atr_pips:.1f} < {self.min} pips"
        if atr_pips > self.max:
            return False, f"Too volatile: ATR={atr_pips:.1f} > {self.max} pips"
        return True, f"Volatility OK: ATR={atr_pips:.1f} pips"
