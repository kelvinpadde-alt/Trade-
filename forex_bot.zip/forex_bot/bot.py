"""
bot.py — Main trading bot orchestrator
Ties together: strategy → filters → risk → broker → logger
"""

import logging
import time
import uuid
from datetime import datetime, timezone

import numpy as np

from broker import BrokerBase, MarketData
from filters import NewsFilter, SessionFilter, VolatilityFilter
from logger_analytics import TradeLogger, TradeRecord
from risk_manager import RiskConfig, RiskManager
from strategy import Strategy, StrategyConfig, TradeSignal

logger = logging.getLogger(__name__)


class ForexBot:
    """
    Production-ready Forex trading bot.

    Decision flow per tick:
    1. Kill switch / daily halt check
    2. Session filter
    3. News filter
    4. Spread check
    5. Strategy signal generation
    6. Volatility filter
    7. R:R validation
    8. Position sizing
    9. Order placement
    10. Log trade
    """

    def __init__(
        self,
        broker: BrokerBase,
        symbols: list[str],
        risk_config: RiskConfig | None = None,
        strategy_config: StrategyConfig | None = None,
        log_dir: str = "logs",
    ):
        self.broker    = broker
        self.symbols   = symbols
        self.risk      = RiskManager(risk_config or RiskConfig())
        self.strategy  = Strategy(strategy_config or StrategyConfig())
        self.session_f = SessionFilter()
        self.news_f    = NewsFilter()
        self.vol_f     = VolatilityFilter()
        self.trade_log = TradeLogger(log_dir)
        self._running  = False
        self._open_trades: dict[str, dict] = {}  # symbol → trade metadata

        logger.info("ForexBot initialized | Symbols: %s", symbols)

    # ── Public controls ────────────────────────────────────────────────

    def start(self, interval_seconds: int = 3600) -> None:
        """
        Run the bot loop. Polls every `interval_seconds` (default 1H candle).
        Call stop() or activate kill switch to halt.
        """
        self._running = True
        logger.info("🤖 Bot started | Interval: %ds", interval_seconds)
        try:
            while self._running:
                self._tick()
                time.sleep(interval_seconds)
        except KeyboardInterrupt:
            logger.info("Bot stopped by user")
        finally:
            self._running = False

    def stop(self) -> None:
        self._running = False
        logger.info("Bot stop requested")

    def kill(self) -> None:
        """Emergency stop — closes nothing, just halts new trades."""
        self.risk.activate_kill_switch()
        self._running = False
        logger.critical("🛑 Emergency kill switch activated")

    def reset(self) -> None:
        """Manual restart after kill switch or daily halt."""
        self.risk.deactivate_kill_switch()
        self.risk.reset_daily()
        logger.info("Bot reset — trading resumed")

    # ── Core tick ──────────────────────────────────────────────────────

    def _tick(self) -> None:
        now = datetime.now(timezone.utc)
        logger.debug("Tick at %s UTC", now.strftime("%Y-%m-%d %H:%M"))

        # ① Master gate
        ok, reason = self.risk.can_trade()
        if not ok:
            logger.info("⛔ %s", reason)
            return

        # ② Session filter
        ok, reason = self.session_f.is_active(now)
        if not ok:
            logger.debug("⏰ %s", reason)
            return

        # ③ News filter
        ok, reason = self.news_f.is_safe(now)
        if not ok:
            logger.info("📰 %s", reason)
            return

        # ④ Process each symbol
        for symbol in self.symbols:
            if symbol in self._open_trades:
                logger.debug("Already have open trade for %s — skipping", symbol)
                continue
            try:
                self._process_symbol(symbol)
            except Exception as e:
                logger.error("Error processing %s: %s", symbol, e, exc_info=True)

    def _process_symbol(self, symbol: str) -> None:
        # Fetch market data
        data = self.broker.get_market_data(symbol, count=300)

        # ④ Spread filter
        ok, reason = self.risk.check_spread(data.spread_pips)
        if not ok:
            logger.info("📊 %s | %s", symbol, reason)
            return

        # ⑤ Strategy signal
        closes = np.array(data.closes)
        highs  = np.array(data.highs)
        lows   = np.array(data.lows)
        signal = self.strategy.generate_signal(closes, highs, lows)

        if signal.direction == "NONE":
            logger.debug("%s | No signal: %s", symbol, signal.reason)
            return

        logger.info("📶 Signal: %s | %s", symbol, signal.reason)

        # ⑥ Volatility guard (redundant safety check)
        atr_pips = signal.atr / 0.0001
        ok, reason = self.vol_f.is_acceptable(atr_pips)
        if not ok:
            logger.info("⚡ %s | %s", symbol, reason)
            return

        # ⑦ R:R validation
        ok, reason = self.risk.validate_rr(signal.entry, signal.stop_loss, signal.take_profit)
        if not ok:
            logger.warning("📐 %s | %s", symbol, reason)
            return

        # ⑧ Position sizing
        lot_size = self.risk.calculate_lot_size(
            entry=signal.entry,
            stop_loss=signal.stop_loss,
        )
        if lot_size <= 0:
            logger.error("Zero lot size for %s — skipping", symbol)
            return

        # ⑨ Place order
        result = self.broker.place_order(
            symbol=symbol,
            direction=signal.direction,
            lots=lot_size,
            stop_loss=signal.stop_loss,
            take_profit=signal.take_profit,
        )

        if not result.success:
            logger.error("Order failed for %s: %s", symbol, result.message)
            return

        fill_price = result.fill_price or signal.entry

        # ⑩ Slippage check (post-fill)
        slippage_pips = abs(fill_price - signal.entry) / 0.0001
        ok, slip_reason = self.risk.check_slippage(slippage_pips)
        if not ok:
            logger.warning("Slippage warning on %s: %s", symbol, slip_reason)
            # Note: order already placed — log but don't cancel (broker-dependent)

        # Store open trade metadata
        self._open_trades[symbol] = {
            "order_id":   result.order_id,
            "direction":  signal.direction,
            "entry":      fill_price,
            "stop_loss":  signal.stop_loss,
            "take_profit": signal.take_profit,
            "lot_size":   lot_size,
            "open_time":  datetime.now(timezone.utc).isoformat(),
            "atr":        signal.atr,
            "signal":     signal.reason,
            "spread":     data.spread_pips,
        }

        logger.info(
            "✅ ORDER PLACED | %s %s %.2f lots @ %.5f | SL=%.5f TP=%.5f | ID=%s",
            signal.direction, symbol, lot_size, fill_price,
            signal.stop_loss, signal.take_profit, result.order_id,
        )

    def record_close(
        self,
        symbol: str,
        exit_price: float,
        close_reason: str = "TP",
    ) -> None:
        """
        Call this when a trade closes (via webhook, polling, or simulation).
        Updates risk manager and writes trade log.
        """
        trade = self._open_trades.pop(symbol, None)
        if not trade:
            logger.warning("No open trade found for %s", symbol)
            return

        direction = trade["direction"]
        pip_diff  = (exit_price - trade["entry"]) / 0.0001
        if direction == "SELL":
            pip_diff = -pip_diff

        pnl_pips = pip_diff
        pnl_usd  = pip_diff * 10.0 * trade["lot_size"]  # standard lot

        outcome = "WIN" if pnl_usd > 0 else ("LOSS" if pnl_usd < 0 else "BREAKEVEN")

        # Update risk manager
        account = self.broker.get_account()
        self.risk.record_trade_result(pnl_usd, account.equity)
        self.risk.cfg.account_balance = account.balance  # sync balance

        # Log trade
        record = TradeRecord(
            trade_id      = trade["order_id"],
            symbol        = symbol,
            direction     = direction,
            open_time     = trade["open_time"],
            close_time    = datetime.now(timezone.utc).isoformat(),
            entry_price   = trade["entry"],
            exit_price    = exit_price,
            stop_loss     = trade["stop_loss"],
            take_profit   = trade["take_profit"],
            lot_size      = trade["lot_size"],
            pnl           = round(pnl_usd, 2),
            pnl_pips      = round(pnl_pips, 1),
            outcome       = outcome,
            close_reason  = close_reason,
            spread_pips   = trade["spread"],
            atr           = trade["atr"],
            signal_reason = trade["signal"],
        )
        self.trade_log.log(record)

        logger.info(
            "🏁 TRADE CLOSED | %s %s | PnL=$%.2f (%.1f pips) | %s",
            symbol, direction, pnl_usd, pnl_pips, outcome,
        )

    def report(self) -> None:
        self.trade_log.print_report()
