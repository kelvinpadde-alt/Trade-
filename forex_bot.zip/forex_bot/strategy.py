"""
strategy.py — Rule-based trend-following strategy
EMA trend filter + RSI confirmation + ATR-based SL/TP
"""

import logging
from dataclasses import dataclass
from typing import Optional
import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class StrategyConfig:
    # Trend filter
    ema_fast: int = 21
    ema_slow: int = 50
    ema_trend: int = 200

    # Entry confirmation
    rsi_period: int = 14
    rsi_overbought: float = 70.0
    rsi_oversold: float = 30.0

    # ATR for dynamic SL/TP
    atr_period: int = 14
    atr_sl_multiplier: float = 1.5    # SL = entry ± ATR * 1.5
    atr_tp_multiplier: float = 3.0    # TP = entry ± ATR * 3.0  (2:1 R:R)

    # Filters
    min_atr_pips: float = 5.0         # Avoid dead markets
    max_atr_pips: float = 50.0        # Avoid extreme volatility


@dataclass
class TradeSignal:
    direction: str          # "BUY" | "SELL" | "NONE"
    entry: float
    stop_loss: float
    take_profit: float
    atr: float
    reason: str


class Strategy:
    """
    Signal generation pipeline.
    ALL conditions must align before a signal is issued.
    """

    def __init__(self, config: Optional[StrategyConfig] = None):
        self.cfg = config or StrategyConfig()

    def generate_signal(self, closes: np.ndarray, highs: np.ndarray, lows: np.ndarray) -> TradeSignal:
        """
        Evaluate market conditions and return a trade signal.

        Args:
            closes: 1-D array of closing prices (oldest → newest)
            highs:  1-D array of high prices
            lows:   1-D array of low prices
        """
        if len(closes) < self.cfg.ema_trend + self.cfg.atr_period:
            return self._no_signal("Insufficient data")

        # ── Indicators ──────────────────────────────────────────────────
        ema_fast  = self._ema(closes, self.cfg.ema_fast)
        ema_slow  = self._ema(closes, self.cfg.ema_slow)
        ema_trend = self._ema(closes, self.cfg.ema_trend)
        rsi       = self._rsi(closes, self.cfg.rsi_period)
        atr       = self._atr(highs, lows, closes, self.cfg.atr_period)

        price = closes[-1]

        # ── Volatility filter ───────────────────────────────────────────
        atr_pips = atr / 0.0001  # assumes 4-decimal pair
        if atr_pips < self.cfg.min_atr_pips:
            return self._no_signal(f"Market too quiet (ATR={atr_pips:.1f} pips)")
        if atr_pips > self.cfg.max_atr_pips:
            return self._no_signal(f"Market too volatile (ATR={atr_pips:.1f} pips)")

        sl_dist = atr * self.cfg.atr_sl_multiplier
        tp_dist = atr * self.cfg.atr_tp_multiplier

        # ── BUY conditions ───────────────────────────────────────────────
        # 1. Price above 200 EMA (uptrend)
        # 2. Fast EMA crossed above slow EMA (momentum)
        # 3. RSI not overbought (room to run)
        if (price > ema_trend and
                ema_fast > ema_slow and
                rsi < self.cfg.rsi_overbought):
            entry     = price
            stop_loss = entry - sl_dist
            take_profit = entry + tp_dist
            return TradeSignal(
                direction="BUY",
                entry=entry,
                stop_loss=stop_loss,
                take_profit=take_profit,
                atr=atr,
                reason=(
                    f"BUY | Price({price:.5f}) > EMA200({ema_trend:.5f}) | "
                    f"EMA{self.cfg.ema_fast}({ema_fast:.5f}) > EMA{self.cfg.ema_slow}({ema_slow:.5f}) | "
                    f"RSI={rsi:.1f}"
                ),
            )

        # ── SELL conditions ──────────────────────────────────────────────
        # 1. Price below 200 EMA (downtrend)
        # 2. Fast EMA crossed below slow EMA (momentum)
        # 3. RSI not oversold (room to fall)
        if (price < ema_trend and
                ema_fast < ema_slow and
                rsi > self.cfg.rsi_oversold):
            entry     = price
            stop_loss = entry + sl_dist
            take_profit = entry - tp_dist
            return TradeSignal(
                direction="SELL",
                entry=entry,
                stop_loss=stop_loss,
                take_profit=take_profit,
                atr=atr,
                reason=(
                    f"SELL | Price({price:.5f}) < EMA200({ema_trend:.5f}) | "
                    f"EMA{self.cfg.ema_fast}({ema_fast:.5f}) < EMA{self.cfg.ema_slow}({ema_slow:.5f}) | "
                    f"RSI={rsi:.1f}"
                ),
            )

        return self._no_signal("No confluence")

    # ── Indicator helpers ────────────────────────────────────────────────

    @staticmethod
    def _ema(series: np.ndarray, period: int) -> float:
        if len(series) < period:
            return series[-1]
        k = 2.0 / (period + 1)
        ema = series[0]
        for price in series[1:]:
            ema = price * k + ema * (1 - k)
        return ema

    @staticmethod
    def _rsi(closes: np.ndarray, period: int) -> float:
        deltas = np.diff(closes[-period - 1:])
        gains  = np.where(deltas > 0, deltas, 0.0)
        losses = np.where(deltas < 0, -deltas, 0.0)
        avg_gain = gains.mean()
        avg_loss = losses.mean()
        if avg_loss == 0:
            return 100.0
        rs = avg_gain / avg_loss
        return 100.0 - (100.0 / (1 + rs))

    @staticmethod
    def _atr(highs: np.ndarray, lows: np.ndarray, closes: np.ndarray, period: int) -> float:
        tr_list = []
        for i in range(1, len(closes)):
            tr = max(
                highs[i] - lows[i],
                abs(highs[i] - closes[i - 1]),
                abs(lows[i] - closes[i - 1]),
            )
            tr_list.append(tr)
        return float(np.mean(tr_list[-period:]))

    @staticmethod
    def _no_signal(reason: str) -> TradeSignal:
        return TradeSignal(direction="NONE", entry=0, stop_loss=0,
                           take_profit=0, atr=0, reason=reason)
