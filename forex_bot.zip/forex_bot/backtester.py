"""
backtester.py — Historical simulation engine
Walk-forward backtesting with full risk management applied.
"""

import logging
from dataclasses import dataclass
from typing import List

import numpy as np

from logger_analytics import TradeLogger, TradeRecord
from risk_manager import RiskConfig, RiskManager
from strategy import Strategy, StrategyConfig, TradeSignal

logger = logging.getLogger(__name__)


@dataclass
class OHLCV:
    open:   float
    high:   float
    low:    float
    close:  float
    volume: float = 0


class Backtester:
    """
    Walk-forward backtester.
    - Feeds historical candles to the strategy one-by-one
    - Applies full risk management (same as live)
    - Simulates SL/TP fills on subsequent candles
    - Outputs performance metrics
    """

    def __init__(
        self,
        candles: List[OHLCV],
        risk_config: RiskConfig | None = None,
        strategy_config: StrategyConfig | None = None,
        pip_value: float = 10.0,
        pip_size: float = 0.0001,
    ):
        self.candles    = candles
        self.risk       = RiskManager(risk_config or RiskConfig())
        self.strategy   = Strategy(strategy_config or StrategyConfig())
        self.pip_value  = pip_value
        self.pip_size   = pip_size
        self.trade_log  = TradeLogger("logs/backtest")
        self._results: list[dict] = []

    def run(self, warmup: int = 250) -> dict:
        """
        Run simulation. `warmup` candles are used to initialize indicators only.
        Returns performance summary.
        """
        logger.info("Starting backtest | %d candles | warmup=%d", len(self.candles), warmup)

        balance  = self.risk.cfg.account_balance
        equity   = balance
        open_trade = None  # Only one trade at a time per symbol

        for i in range(warmup, len(self.candles)):
            candle = self.candles[i]
            window = self.candles[:i + 1]

            closes = np.array([c.close for c in window])
            highs  = np.array([c.high  for c in window])
            lows   = np.array([c.low   for c in window])

            # ── Check open trade for SL/TP hit ──────────────────────────
            if open_trade:
                hit, exit_price, reason = self._check_exit(open_trade, candle)
                if hit:
                    direction = open_trade["direction"]
                    pip_diff  = (exit_price - open_trade["entry"]) / self.pip_size
                    if direction == "SELL":
                        pip_diff = -pip_diff
                    pnl = pip_diff * self.pip_value * open_trade["lots"]
                    balance += pnl
                    equity   = balance

                    outcome = "WIN" if pnl > 0 else ("LOSS" if pnl < 0 else "BREAKEVEN")
                    self._results.append(dict(
                        entry=open_trade["entry"], exit=exit_price,
                        direction=direction, pnl=pnl, outcome=outcome,
                        reason=reason, candle_idx=i,
                    ))
                    self.risk.record_trade_result(pnl, equity)
                    self.risk.cfg.account_balance = balance
                    open_trade = None
                    logger.debug("Close at candle %d | %s | PnL=%.2f", i, outcome, pnl)

            # ── Check if we can open a new trade ────────────────────────
            if open_trade:
                continue  # Already in a trade

            ok, reason = self.risk.can_trade()
            if not ok:
                continue

            signal = self.strategy.generate_signal(closes, highs, lows)
            if signal.direction == "NONE":
                continue

            ok, rr_msg = self.risk.validate_rr(signal.entry, signal.stop_loss, signal.take_profit)
            if not ok:
                continue

            lots = self.risk.calculate_lot_size(signal.entry, signal.stop_loss,
                                                 self.pip_value, self.pip_size)
            if lots <= 0:
                continue

            open_trade = dict(
                direction  = signal.direction,
                entry      = candle.close,
                stop_loss  = signal.stop_loss,
                take_profit= signal.take_profit,
                lots       = lots,
                candle_idx = i,
            )
            logger.debug("Open %s at candle %d | Entry=%.5f SL=%.5f TP=%.5f",
                         signal.direction, i, candle.close, signal.stop_loss, signal.take_profit)

        return self._compute_summary(balance)

    def _check_exit(self, trade: dict, candle: OHLCV) -> tuple[bool, float, str]:
        """Check if candle hits SL or TP. TP checked first (optimistic)."""
        direction = trade["direction"]

        if direction == "BUY":
            if candle.high >= trade["take_profit"]:
                return True, trade["take_profit"], "TP"
            if candle.low  <= trade["stop_loss"]:
                return True, trade["stop_loss"], "SL"
        else:  # SELL
            if candle.low  <= trade["take_profit"]:
                return True, trade["take_profit"], "TP"
            if candle.high >= trade["stop_loss"]:
                return True, trade["stop_loss"], "SL"

        return False, 0.0, ""

    def _compute_summary(self, final_balance: float) -> dict:
        if not self._results:
            return {"message": "No trades taken in backtest"}

        wins   = [r for r in self._results if r["outcome"] == "WIN"]
        losses = [r for r in self._results if r["outcome"] == "LOSS"]
        total  = len(self._results)
        total_pnl = sum(r["pnl"] for r in self._results)

        gross_profit = sum(r["pnl"] for r in wins) if wins else 0
        gross_loss   = abs(sum(r["pnl"] for r in losses)) if losses else 0
        pf = gross_profit / gross_loss if gross_loss > 0 else float("inf")

        # Drawdown
        equity = self.risk.cfg.account_balance
        peak = equity
        max_dd = 0.0
        running = equity
        for r in self._results:
            running += r["pnl"]
            peak = max(peak, running)
            max_dd = max(max_dd, peak - running)

        summary = {
            "total_trades":     total,
            "wins":             len(wins),
            "losses":           len(losses),
            "win_rate_pct":     round(len(wins) / total * 100, 1),
            "total_pnl_usd":    round(total_pnl, 2),
            "profit_factor":    round(pf, 2),
            "max_drawdown_usd": round(max_dd, 2),
            "final_balance":    round(final_balance, 2),
            "return_pct":       round((total_pnl / self.risk.cfg.account_balance) * 100, 2),
        }

        sep = "─" * 48
        print(f"\n{sep}")
        print("  BACKTEST RESULTS")
        print(sep)
        for k, v in summary.items():
            print(f"  {k.replace('_',' ').title():<30} {v}")
        print(f"{sep}\n")

        return summary
